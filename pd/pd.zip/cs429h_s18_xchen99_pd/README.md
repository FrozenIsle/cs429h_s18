# Fun-Interpreter-Final

Team members: David Chen, David Lai, David Yuan

Interpreter written in Go that reads and executes a program written in a basic programming language (Fun). The Fun language will feature if statements, while/for loops, types, string concatenation/multiplication/division, type inference, type checking, numeric comparisons (< and >), numeric addition, multiplication, division

Our "Fun" language supports the following types:
int, float, char, String

Sadly, there is no casting between different types

Declaring/initializing variables will be in the following syntax

a = 5

b = 13.37

c = '!'

d = "Hello World!"
